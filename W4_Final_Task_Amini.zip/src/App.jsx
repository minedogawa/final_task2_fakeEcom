import "./App.css"
import { BsPlus, BsEyeFill, BsBag } from "react-icons/bs"
import { CiLogout } from "react-icons/ci"
import { IoArrowBackCircle } from "react-icons/io5"
import { IoMdArrowForward, IoMdAdd, IoMdClose, IoMdRemove } from "react-icons/io"
import { FiTrash2 } from "react-icons/fi"

const App = () => {
	return (
		<div></div>
	)
}

export default App
